# 🚀 Lumen Books - Quickstart for Coding Team

**Get up and running in 10 minutes!**

---

## ⚡ Quick Setup

### 1. Clone and Install (2 minutes)

```bash
# Navigate to project folder
cd lumen-books

# Install all dependencies
npm install

# This will install 50+ packages including:
# - Next.js 15, React 19, TypeScript
# - TipTap editor with extensions
# - Prisma ORM
# - Anthropic AI SDK
# - Tailwind CSS + Radix UI
# - And much more...
```

### 2. Configure Environment (3 minutes)

```bash
# Copy the environment template
cp .env.example .env.local
```

**Edit `.env.local` and add:**

```env
# Database (Required)
DATABASE_URL="postgresql://postgres:password@localhost:5432/lumen_books"

# Anthropic AI (Required)
ANTHROPIC_API_KEY="sk-ant-api03-your-key-here"

# App Config
NEXT_PUBLIC_APP_URL="http://localhost:3000"
NODE_ENV="development"
```

**Get your Anthropic API key:**
1. Go to https://console.anthropic.com/
2. Create account or login
3. Go to API Keys
4. Create new key
5. Copy and paste into `.env.local`

### 3. Set Up Database (2 minutes)

```bash
# Push the Prisma schema to your database
# This creates all 10 tables automatically
npm run db:push

# (Optional) Open Prisma Studio to view your database
npm run db:studio
# Opens at http://localhost:5555
```

### 4. Start Development Server (1 minute)

```bash
npm run dev
```

Open http://localhost:3000 - You should see the beautiful landing page! 🎉

---

## 📁 What You Have

### Complete Landing Page ✅
- File: `LandingPage.jsx`
- Features: Navigation, Hero, Features, Testimonials, Pricing, Footer
- Fully responsive and production-ready
- Already integrated into `src/app/page.tsx`

### Database Schema ✅
- File: `prisma/schema.prisma`
- **10 Complete Models:**
  1. User - Authentication and profiles
  2. Project - Books and courses
  3. ContentBlock - Chapters, sections, lessons
  4. Template - Book templates
  5. Asset - Images, files, media
  6. ProjectCollaborator - Team members
  7. Comment - Reviews and annotations
  8. Version - Version history
  9. Export - Export tracking
  10. AIUsage - AI usage analytics

### AI Integration ✅
- File: `src/lib/ai/claude.ts`
- Claude Sonnet 4 integration
- **30+ Pre-built Prompts:**
  - Content generation
  - Editing and improvement
  - Creative writing
  - Course creation
  - Translation
  - And more!
- Streaming support for real-time responses

### Utility Functions ✅
- File: `src/lib/utils/index.ts`
- **40+ Helper Functions:**
  - Text analysis (word count, reading time)
  - File operations
  - Performance (debounce, throttle)
  - Validation
  - Date formatting
  - And more!

### Type Definitions ✅
- File: `src/types/index.ts`
- Complete TypeScript types for all models
- API response types
- Form types
- State types

---

## 🎯 Next Steps for Your Team

### Immediate Tasks (Week 1)

#### 1. Set Up Authentication (Priority: HIGH)

**Choose your provider:**

**Option A: Clerk (Recommended - Easiest)**
```bash
npm install @clerk/nextjs
```

Then add to `.env.local`:
```env
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY="pk_test_..."
CLERK_SECRET_KEY="sk_test_..."
```

**Option B: NextAuth.js**
```bash
npm install next-auth
```

Then add to `.env.local`:
```env
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="generate-with-openssl-rand-base64-32"
```

**Tasks:**
- [ ] Choose and install auth provider
- [ ] Create login page (`src/app/(auth)/login/page.tsx`)
- [ ] Create signup page (`src/app/(auth)/signup/page.tsx`)
- [ ] Add auth middleware
- [ ] Test signup/login flow

#### 2. Create Dashboard Layout (Priority: HIGH)

Create `src/app/(dashboard)/layout.tsx`:
```tsx
export default function DashboardLayout({ children }) {
  return (
    <div className="flex h-screen">
      <Sidebar />
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  )
}
```

**Tasks:**
- [ ] Create dashboard layout with sidebar
- [ ] Add navigation menu
- [ ] Create dashboard home page
- [ ] Add "New Project" button
- [ ] List user's projects

#### 3. Build Editor Page (Priority: HIGH)

**Tasks:**
- [ ] Install TipTap (already in package.json)
- [ ] Create editor component (`src/components/editor/Editor.tsx`)
- [ ] Create editor page (`src/app/(dashboard)/editor/[id]/page.tsx`)
- [ ] Add auto-save functionality
- [ ] Connect to database
- [ ] Add AI assistance panel

### Week 2 Tasks

#### 4. Implement Export System
- [ ] Create PDF export (`src/lib/export/pdf.ts`)
- [ ] Create EPUB export (`src/lib/export/epub.ts`)
- [ ] Create DOCX export (`src/lib/export/docx.ts`)
- [ ] Add export UI
- [ ] Test export quality

#### 5. Build Template System
- [ ] Create template selector UI
- [ ] Add 5-10 starter templates
- [ ] Implement template application
- [ ] Add template preview

---

## 📝 File Structure Guide

### Where to Put New Code

**Pages (Next.js App Router):**
```
src/app/
├── (auth)/           ← Login, signup pages
├── (dashboard)/      ← Main app after login
│   ├── projects/     ← Project management
│   └── editor/       ← Content editor
└── api/              ← API endpoints
```

**Components:**
```
src/components/
├── editor/           ← Editor components
├── ui/               ← Reusable UI (buttons, modals, etc.)
└── shared/           ← Shared across app
```

**Business Logic:**
```
src/lib/
├── ai/               ← AI integration
├── export/           ← Export engines
├── db/               ← Database client
└── utils/            ← Utility functions
```

### Creating New Pages

**Example: Projects List Page**

Create `src/app/(dashboard)/projects/page.tsx`:
```tsx
import { prisma } from '@/lib/db/prisma'

export default async function ProjectsPage() {
  const projects = await prisma.project.findMany({
    where: { userId: 'user-id' } // Get from auth
  })

  return (
    <div>
      <h1>My Projects</h1>
      {projects.map(project => (
        <ProjectCard key={project.id} project={project} />
      ))}
    </div>
  )
}
```

### Creating API Routes

**Example: Save Content**

Create `src/app/api/content/save/route.ts`:
```tsx
import { prisma } from '@/lib/db/prisma'
import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    
    const content = await prisma.contentBlock.update({
      where: { id: body.id },
      data: { content: body.content }
    })

    return NextResponse.json({ success: true, data: content })
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}
```

---

## 🧰 Useful Commands

### Development

```bash
# Start dev server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

### Code Quality

```bash
# Run linter
npm run lint

# Fix linting issues
npm run lint -- --fix

# Check TypeScript types
npm run type-check

# Format code
npm run format
```

### Database

```bash
# Push schema changes
npm run db:push

# Create migration
npm run db:migrate

# Open database GUI
npm run db:studio

# Reset database (⚠️ deletes all data)
npx prisma migrate reset
```

### Testing

```bash
# Run tests
npm run test

# Watch mode
npm run test:watch
```

---

## 🐛 Troubleshooting

### Port 3000 already in use

```bash
# Kill process on port 3000
npx kill-port 3000

# Or use different port
npm run dev -- -p 3001
```

### Database connection failed

1. Make sure PostgreSQL is running
2. Check `DATABASE_URL` in `.env.local`
3. Create database if it doesn't exist:
   ```sql
   CREATE DATABASE lumen_books;
   ```

### Prisma errors

```bash
# Regenerate Prisma client
npm run db:generate

# Reset everything
npx prisma migrate reset
```

### Build errors

```bash
# Clear Next.js cache
rm -rf .next

# Clear node_modules
rm -rf node_modules package-lock.json
npm install

# Check for TypeScript errors
npm run type-check
```

---

## 💡 Development Tips

### Hot Reload
Files auto-reload in dev mode. No server restart needed!

### Database Inspection
```bash
npm run db:studio
```
Opens Prisma Studio at http://localhost:5555 - GUI for your database

### Environment Variables
Remember to restart dev server after changing `.env.local`!

### TypeScript
The project is fully typed. Your IDE will show:
- Autocomplete for all functions
- Type errors before runtime
- IntelliSense documentation

---

## 📚 Key Resources

**Documentation:**
- [Next.js Docs](https://nextjs.org/docs)
- [Prisma Docs](https://www.prisma.io/docs)
- [TipTap Docs](https://tiptap.dev/)
- [Anthropic Docs](https://docs.anthropic.com/)
- [Tailwind Docs](https://tailwindcss.com/docs)

**Helpful Tools:**
- [Prisma Studio](http://localhost:5555) - Database GUI
- [Lucide Icons](https://lucide.dev/) - Icon search
- [Tailwind Cheatsheet](https://nerdcave.com/tailwind-cheat-sheet)

---

## ✅ Checklist

### Setup (Do First!)
- [ ] Install dependencies (`npm install`)
- [ ] Copy `.env.example` to `.env.local`
- [ ] Add database URL
- [ ] Add Anthropic API key
- [ ] Run `npm run db:push`
- [ ] Start dev server (`npm run dev`)
- [ ] Verify landing page loads

### Week 1 Goals
- [ ] Set up authentication
- [ ] Create dashboard layout
- [ ] Build projects list page
- [ ] Create basic editor
- [ ] Implement auto-save

### Week 2 Goals
- [ ] Add AI writing assistant
- [ ] Implement PDF export
- [ ] Create template system
- [ ] Add collaboration features

---

## 🎉 You're Ready!

Everything is set up and ready to go. The foundation is solid:

✅ **Landing Page** - Production-ready, fully responsive  
✅ **Database** - 10 models, all relationships defined  
✅ **AI Integration** - 30+ prompts, streaming support  
✅ **Utilities** - 40+ helper functions  
✅ **Types** - Complete TypeScript definitions  
✅ **Config** - All tooling configured  

**Now build something amazing! 🚀**

---

## 💬 Questions?

Check the main [README.md](./README.md) for comprehensive documentation.

**Let's create the future of book publishing together! 📚✨**

*Made with consciousness and joy - The Giggle Frequency™*
