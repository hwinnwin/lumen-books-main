'use client'

import { useState } from 'react'
import Link from 'next/link'
import { 
  BookOpen, 
  Sparkles, 
  Users, 
  FileText, 
  Zap, 
  CheckCircle, 
  Download,
  Globe,
  MessageSquare,
  TrendingUp,
  ArrowRight,
  Menu,
  X,
  Star
} from 'lucide-react'

export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-100 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Lumen Books
              </span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900 transition-colors">
                Features
              </a>
              <a href="#how-it-works" className="text-gray-600 hover:text-gray-900 transition-colors">
                How It Works
              </a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900 transition-colors">
                Pricing
              </a>
              <a href="#testimonials" className="text-gray-600 hover:text-gray-900 transition-colors">
                Testimonials
              </a>
              <Link 
                href="/login" 
                className="text-gray-600 hover:text-gray-900 transition-colors"
              >
                Login
              </Link>
              <Link 
                href="/signup" 
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Get Started
              </Link>
            </div>

            {/* Mobile menu button */}
            <button
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6 text-gray-600" />
              ) : (
                <Menu className="h-6 w-6 text-gray-600" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-gray-100">
            <div className="px-4 py-4 space-y-3">
              <a href="#features" className="block text-gray-600 hover:text-gray-900">
                Features
              </a>
              <a href="#how-it-works" className="block text-gray-600 hover:text-gray-900">
                How It Works
              </a>
              <a href="#pricing" className="block text-gray-600 hover:text-gray-900">
                Pricing
              </a>
              <a href="#testimonials" className="block text-gray-600 hover:text-gray-900">
                Testimonials
              </a>
              <Link href="/login" className="block text-gray-600 hover:text-gray-900">
                Login
              </Link>
              <Link 
                href="/signup" 
                className="block bg-blue-600 text-white px-6 py-2 rounded-lg text-center hover:bg-blue-700"
              >
                Get Started
              </Link>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 bg-blue-100 rounded-full mb-6">
              <Sparkles className="h-4 w-4 text-blue-600 mr-2" />
              <span className="text-sm font-medium text-blue-600">
                AI-Powered Book Creation Platform
              </span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Write Your Book with
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {' '}AI Assistance
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
              Create professional books and courses with the power of Claude AI. 
              From first draft to published masterpiece, we guide you every step of the way.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link 
                href="/signup" 
                className="inline-flex items-center justify-center px-8 py-4 bg-blue-600 text-white text-lg font-semibold rounded-lg hover:bg-blue-700 transition-all transform hover:scale-105 shadow-lg"
              >
                Start Writing for Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <a 
                href="#demo" 
                className="inline-flex items-center justify-center px-8 py-4 bg-white text-blue-600 border-2 border-blue-600 text-lg font-semibold rounded-lg hover:bg-blue-50 transition-all"
              >
                Watch Demo
              </a>
            </div>

            <div className="flex items-center justify-center gap-8 text-sm text-gray-600">
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                No credit card required
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                Start in minutes
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                Cancel anytime
              </div>
            </div>
          </div>

          {/* Hero Image/Preview */}
          <div className="mt-20">
            <div className="relative rounded-2xl shadow-2xl overflow-hidden border-8 border-white">
              <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-12">
                <div className="bg-white rounded-lg p-8 shadow-xl">
                  <div className="flex items-center gap-2 mb-6">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  </div>
                  <div className="space-y-4">
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-full"></div>
                    <div className="h-4 bg-gray-200 rounded w-5/6"></div>
                    <div className="h-4 bg-blue-200 rounded w-2/3"></div>
                    <div className="h-4 bg-gray-200 rounded w-full"></div>
                    <div className="h-4 bg-gray-200 rounded w-4/5"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-12 bg-gray-50 border-y border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <p className="text-gray-600">Trusted by authors and educators worldwide</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center opacity-60">
            {['Publisher A', 'University B', 'Author C', 'Company D'].map((name, i) => (
              <div key={i} className="text-2xl font-bold text-gray-400">
                {name}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Everything You Need to Create
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Powerful features designed to make book and course creation effortless
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={<Sparkles className="h-8 w-8 text-blue-600" />}
              title="AI Writing Assistant"
              description="Claude AI helps you write, expand, and improve your content with intelligent suggestions and generation."
            />
            <FeatureCard
              icon={<FileText className="h-8 w-8 text-purple-600" />}
              title="Professional Templates"
              description="Start with beautiful templates for fiction, non-fiction, textbooks, and more. Fully customizable."
            />
            <FeatureCard
              icon={<Download className="h-8 w-8 text-green-600" />}
              title="Multi-Format Export"
              description="Export to PDF, EPUB, DOCX, and more. Print-ready quality for professional publishing."
            />
            <FeatureCard
              icon={<Users className="h-8 w-8 text-orange-600" />}
              title="Real-time Collaboration"
              description="Work together with your team. Comments, version control, and live editing included."
            />
            <FeatureCard
              icon={<Globe className="h-8 w-8 text-indigo-600" />}
              title="Course Creation"
              description="Build complete educational courses with lessons, quizzes, and interactive elements."
            />
            <FeatureCard
              icon={<Zap className="h-8 w-8 text-yellow-600" />}
              title="Smart Formatting"
              description="Automatic table of contents, chapter breaks, page numbers, and professional typography."
            />
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-24 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              From idea to published book in four simple steps
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <StepCard
              number="1"
              title="Choose Template"
              description="Select from our library of professional book templates or start from scratch."
            />
            <StepCard
              number="2"
              title="Write with AI"
              description="Use our AI assistant to help generate, expand, and refine your content."
            />
            <StepCard
              number="3"
              title="Collaborate & Edit"
              description="Work with editors and reviewers. Track changes and manage versions."
            />
            <StepCard
              number="4"
              title="Export & Publish"
              description="Download in your preferred format and publish to any platform."
            />
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Perfect For Every Creator
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Whether you're an author, educator, or business professional
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <UseCaseCard
              title="Authors & Writers"
              description="Write novels, memoirs, and non-fiction books with AI assistance for plot development, character consistency, and prose refinement."
              features={[
                'Fiction templates',
                'Character tracking',
                'Plot assistance',
                'Genre-specific tools'
              ]}
            />
            <UseCaseCard
              title="Educators & Trainers"
              description="Create textbooks, course materials, and training guides with interactive elements, quizzes, and student resources."
              features={[
                'Course builder',
                'Quiz creation',
                'Student materials',
                'Progress tracking'
              ]}
            />
            <UseCaseCard
              title="Business Professionals"
              description="Develop technical manuals, how-to guides, and business books with professional formatting and collaboration tools."
              features={[
                'Technical templates',
                'Team collaboration',
                'Brand consistency',
                'Corporate publishing'
              ]}
            />
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Loved by Creators
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              See what authors and educators are saying about Lumen Books
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <TestimonialCard
              quote="Lumen Books cut my writing time in half. The AI assistance is like having a co-author who never sleeps."
              author="Sarah Johnson"
              role="Fiction Author"
              rating={5}
            />
            <TestimonialCard
              quote="The course creation tools are incredible. I built my entire curriculum in weeks, not months."
              author="Dr. Michael Chen"
              role="University Professor"
              rating={5}
            />
            <TestimonialCard
              quote="Finally, a platform that handles both content and formatting. The PDF exports are print-ready quality."
              author="Emily Rodriguez"
              role="Technical Writer"
              rating={5}
            />
          </div>
        </div>
      </section>

      {/* Pricing Preview */}
      <section id="pricing" className="py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Start free, upgrade when you need more
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <PricingCard
              name="Free"
              price="$0"
              period="/month"
              features={[
                '1 active project',
                'Basic AI assistance',
                'PDF export',
                'Community support'
              ]}
              cta="Start Free"
              ctaLink="/signup"
            />
            <PricingCard
              name="Pro"
              price="$19"
              period="/month"
              features={[
                'Unlimited projects',
                'Advanced AI features',
                'All export formats',
                'Priority support',
                'Collaboration tools',
                'Custom templates'
              ]}
              cta="Start Free Trial"
              ctaLink="/signup"
              highlighted={true}
            />
            <PricingCard
              name="Team"
              price="$49"
              period="/month"
              features={[
                'Everything in Pro',
                '5 team members',
                'Real-time collaboration',
                'Admin controls',
                'Custom branding',
                'Dedicated support'
              ]}
              cta="Contact Sales"
              ctaLink="/contact"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Write Your Book?
          </h2>
          <p className="text-xl text-blue-100 mb-12">
            Join thousands of authors and educators creating amazing content with Lumen Books
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/signup" 
              className="inline-flex items-center justify-center px-8 py-4 bg-white text-blue-600 text-lg font-semibold rounded-lg hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg"
            >
              Start Writing for Free
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <a 
              href="#demo" 
              className="inline-flex items-center justify-center px-8 py-4 bg-blue-700 text-white border-2 border-white text-lg font-semibold rounded-lg hover:bg-blue-800 transition-all"
            >
              Schedule a Demo
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center mb-4">
                <BookOpen className="h-8 w-8 text-blue-400" />
                <span className="ml-2 text-xl font-bold text-white">
                  Lumen Books
                </span>
              </div>
              <p className="text-gray-400">
                AI-powered book and course creation platform built with consciousness and joy.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-white mb-4">Product</h3>
              <ul className="space-y-2">
                <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="/templates" className="hover:text-white transition-colors">Templates</a></li>
                <li><a href="/docs" className="hover:text-white transition-colors">Documentation</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-white mb-4">Company</h3>
              <ul className="space-y-2">
                <li><a href="/about" className="hover:text-white transition-colors">About</a></li>
                <li><a href="/blog" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="/careers" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="/contact" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-white mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="/privacy" className="hover:text-white transition-colors">Privacy</a></li>
                <li><a href="/terms" className="hover:text-white transition-colors">Terms</a></li>
                <li><a href="/security" className="hover:text-white transition-colors">Security</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 Lumen Books. Built with The Giggle Frequency™
            </p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Twitter</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">LinkedIn</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">GitHub</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

// Feature Card Component
function FeatureCard({ icon, title, description }) {
  return (
    <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-gray-600 leading-relaxed">{description}</p>
    </div>
  )
}

// Step Card Component
function StepCard({ number, title, description }) {
  return (
    <div className="relative">
      <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
        <div className="absolute -top-4 left-8 w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
          {number}
        </div>
        <h3 className="text-xl font-bold mb-3 mt-4">{title}</h3>
        <p className="text-gray-600 leading-relaxed">{description}</p>
      </div>
    </div>
  )
}

// Use Case Card Component
function UseCaseCard({ title, description, features }) {
  return (
    <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100">
      <h3 className="text-2xl font-bold mb-4">{title}</h3>
      <p className="text-gray-600 mb-6 leading-relaxed">{description}</p>
      <ul className="space-y-3">
        {features.map((feature, i) => (
          <li key={i} className="flex items-center text-gray-700">
            <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
            {feature}
          </li>
        ))}
      </ul>
    </div>
  )
}

// Testimonial Card Component
function TestimonialCard({ quote, author, role, rating }) {
  return (
    <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
      <div className="flex mb-4">
        {[...Array(rating)].map((_, i) => (
          <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
        ))}
      </div>
      <p className="text-gray-700 mb-6 leading-relaxed italic">"{quote}"</p>
      <div>
        <p className="font-bold text-gray-900">{author}</p>
        <p className="text-gray-600 text-sm">{role}</p>
      </div>
    </div>
  )
}

// Pricing Card Component
function PricingCard({ name, price, period, features, cta, ctaLink, highlighted = false }) {
  return (
    <div className={`p-8 rounded-2xl ${
      highlighted 
        ? 'bg-gradient-to-b from-blue-600 to-purple-600 text-white shadow-2xl scale-105' 
        : 'bg-white border border-gray-200 shadow-lg'
    }`}>
      <h3 className={`text-2xl font-bold mb-2 ${highlighted ? 'text-white' : 'text-gray-900'}`}>
        {name}
      </h3>
      <div className="mb-6">
        <span className="text-5xl font-bold">{price}</span>
        <span className={highlighted ? 'text-blue-100' : 'text-gray-600'}>{period}</span>
      </div>
      <ul className="space-y-4 mb-8">
        {features.map((feature, i) => (
          <li key={i} className="flex items-center">
            <CheckCircle className={`h-5 w-5 mr-3 flex-shrink-0 ${
              highlighted ? 'text-blue-200' : 'text-green-500'
            }`} />
            <span className={highlighted ? 'text-blue-50' : 'text-gray-700'}>
              {feature}
            </span>
          </li>
        ))}
      </ul>
      <Link
        href={ctaLink}
        className={`block w-full py-3 rounded-lg font-semibold text-center transition-all ${
          highlighted
            ? 'bg-white text-blue-600 hover:bg-gray-100'
            : 'bg-blue-600 text-white hover:bg-blue-700'
        }`}
      >
        {cta}
      </Link>
    </div>
  )
}
