# 📚 Lumen Books - Production-Ready Book & Course Creation Platform

> **AI-powered platform for creating professional books and educational courses**  
> Built with Next.js 15, TipTap, Claude AI, and PostgreSQL

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.7-blue)](https://www.typescriptlang.org/)
[![Next.js](https://img.shields.io/badge/Next.js-15-black)](https://nextjs.org/)

---

## 🎯 Overview

Lumen Books is a comprehensive platform that enables users to create any type of book or educational content with AI assistance. From novels to textbooks, technical manuals to online courses - all with professional-grade export quality.

### Key Features

- ✨ **AI Writing Assistant** - Claude AI integration for content generation
- 📝 **Rich Text Editor** - TipTap-based editor with advanced formatting
- 📤 **Multi-Format Export** - PDF, EPUB, DOCX, and more
- 👥 **Real-time Collaboration** - Work together with version control
- 🎨 **Template Library** - Professional templates for every genre
- 🎓 **Course Creation** - Complete educational content builder
- 📊 **Analytics** - Track progress and engagement
- 🔒 **Secure** - Type-safe, tested, production-ready

---

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm 9+
- PostgreSQL database
- Anthropic API key ([Get one here](https://console.anthropic.com/))

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/hwinnwin/lumen-books.git
cd lumen-books

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env.local
# Edit .env.local with your credentials

# 4. Set up the database
npm run db:push

# 5. Run the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to see the app!

---

## 📁 Project Structure

```
lumen-books/
├── LandingPage.jsx           # Complete landing page component
├── prisma/
│   └── schema.prisma         # Database schema (10 models)
├── src/
│   ├── app/                  # Next.js 15 app router
│   │   ├── layout.tsx        # Root layout
│   │   ├── page.tsx          # Homepage
│   │   ├── (auth)/           # Auth pages (login, signup)
│   │   ├── (dashboard)/      # Main app
│   │   │   ├── projects/     # Project management
│   │   │   └── editor/       # Content editor
│   │   └── api/              # API routes
│   ├── components/
│   │   ├── editor/           # Editor components
│   │   ├── ui/               # Reusable UI components
│   │   └── shared/           # Shared components
│   ├── lib/
│   │   ├── ai/
│   │   │   └── claude.ts     # AI integration + 30+ prompts
│   │   ├── export/           # Export engines (PDF, EPUB, DOCX)
│   │   ├── db/
│   │   │   └── prisma.ts     # Database client
│   │   └── utils/
│   │       └── index.ts      # 40+ utility functions
│   ├── hooks/                # React hooks
│   ├── types/
│   │   └── index.ts          # TypeScript definitions
│   └── styles/
│       └── globals.css       # Global styles
└── docs/                     # Documentation
```

---

## 🛠 Tech Stack

### Core Framework
- **Next.js 15** - React framework with App Router
- **TypeScript 5.7** - Type safety
- **React 19** - Latest React features

### Database & ORM
- **PostgreSQL** - Production database
- **Prisma 5.22** - Type-safe ORM
- **10 Database Models** - Complete schema

### Editor
- **TipTap 2.10** - Extensible rich text editor
- **ProseMirror** - Editor foundation
- **Y.js** - CRDT for collaboration

### AI Integration
- **Anthropic Claude** - Sonnet 4 model
- **30+ Smart Prompts** - Pre-built for common tasks
- **Streaming Support** - Real-time responses

### UI & Styling
- **Tailwind CSS 3.4** - Utility-first styling
- **Radix UI** - Accessible primitives
- **Lucide React** - Beautiful icons
- **Framer Motion** - Smooth animations

### Export Engines
- **PDF-Lib** - PDF generation
- **DOCX** - Word documents
- **Sharp** - Image processing

### State Management
- **Zustand** - Lightweight state
- **Jotai** - Atomic state
- **TanStack Query** - Server state

---

## 📊 Database Schema

### Core Models

- **User** - User accounts and authentication
- **Project** - Books and courses
- **ContentBlock** - Chapters, sections, lessons
- **Template** - Book templates
- **Asset** - Images, files, media
- **ProjectCollaborator** - Team members and roles
- **Comment** - Reviews and annotations
- **Version** - Version control
- **Export** - Export history
- **AIUsage** - AI usage tracking

### Relationships

```
User ─┬─> Project ─┬─> ContentBlock (hierarchical)
      │            ├─> Asset
      │            ├─> ProjectCollaborator
      │            ├─> Comment
      │            ├─> Version
      │            └─> Export
      │
      ├─> ProjectCollaborator
      ├─> Comment
      └─> Version
```

---

## 🎨 Landing Page

The `LandingPage.jsx` component is a complete, production-ready landing page featuring:

### Sections
- ✅ **Hero** with gradient background and CTA
- ✅ **Social Proof** with company logos
- ✅ **Features** showcase (6 feature cards)
- ✅ **How It Works** (4-step process)
- ✅ **Use Cases** for different user types
- ✅ **Testimonials** with ratings
- ✅ **Pricing** with 3 tiers
- ✅ **CTA Section** with dual CTAs
- ✅ **Footer** with links and copyright

### Features
- Fully responsive (mobile, tablet, desktop)
- Mobile menu with hamburger icon
- Smooth scroll navigation
- Beautiful gradients and shadows
- Accessible with semantic HTML
- SEO-friendly structure

### Usage

```jsx
import LandingPage from './LandingPage'

export default function HomePage() {
  return <LandingPage />
}
```

---

## 🤖 AI Integration

### Claude AI Setup

The `src/lib/ai/claude.ts` file provides comprehensive AI integration:

```typescript
import { generateContent, prompts } from '@/lib/ai/claude'

// Generate content
const text = await generateContent(
  prompts.expandParagraph('Your text here')
)

// Streaming responses
const stream = await generateContentStream(
  prompts.generateChapter(outline, 'Chapter 1')
)

for await (const chunk of stream) {
  console.log(chunk)
}
```

### Available Prompts (30+)

**Content Generation:**
- `expandParagraph` - Add detail to text
- `generateChapter` - Write complete chapters
- `generateOutline` - Create book outlines
- `continueStory` - Continue narratives

**Editing:**
- `improveGrammar` - Fix grammar and clarity
- `changeTone` - Adjust writing tone
- `makeMoreConcise` - Shorten text
- `makeMoreDetailed` - Add depth

**Creative Writing:**
- `generateDialogue` - Create conversations
- `generateDescription` - Write vivid descriptions
- `developCharacter` - Build character profiles

**Non-Fiction:**
- `explainConcept` - Explain topics clearly
- `generateExample` - Create examples
- `createExercise` - Build practice problems

**Course Creation:**
- `createLessonPlan` - Plan lessons
- `generateQuiz` - Create assessments
- `createStudyGuide` - Build study materials

[See full list in `src/lib/ai/claude.ts`]

---

## 🧰 Utility Functions

### Text Analysis

```typescript
import { wordCount, readingTime, estimateReadingLevel } from '@/lib/utils'

const words = wordCount(text)          // 1,234
const minutes = readingTime(text)      // 6 minutes
const level = estimateReadingLevel(text) // "High School"
```

### File Operations

```typescript
import { formatFileSize, sanitizeFilename } from '@/lib/utils'

const size = formatFileSize(1234567)       // "1.18 MB"
const safe = sanitizeFilename('my file!.pdf') // "my_file.pdf"
```

### Performance

```typescript
import { debounce, throttle } from '@/lib/utils'

const saveContent = debounce(async (content) => {
  await api.save(content)
}, 1000)

const handleScroll = throttle(() => {
  console.log('Scrolling...')
}, 100)
```

[See all 40+ functions in `src/lib/utils/index.ts`]

---

## 📝 Development Workflow

### Available Scripts

```bash
# Development
npm run dev              # Start dev server
npm run build            # Build for production
npm run start            # Start production server

# Code Quality
npm run lint             # Run ESLint
npm run type-check       # Check TypeScript
npm run format           # Format with Prettier

# Database
npm run db:push          # Push schema changes
npm run db:studio        # Open Prisma Studio
npm run db:migrate       # Create migration
npm run db:generate      # Generate Prisma client

# Testing
npm run test             # Run tests
npm run test:watch       # Watch mode
```

### Development Guidelines

1. **Code Style**
   - Use TypeScript for type safety
   - Follow ESLint and Prettier rules
   - Use meaningful variable names

2. **Components**
   - Create reusable components in `src/components/`
   - Use client components (`'use client'`) when needed
   - Keep components focused and small

3. **API Routes**
   - Place in `src/app/api/`
   - Use proper error handling
   - Validate inputs with Zod

4. **Database**
   - Modify `prisma/schema.prisma`
   - Run `npm run db:push` after changes
   - Use Prisma Studio to inspect data

---

## 🔧 Configuration

### Environment Variables

Create `.env.local` with:

```env
# Required
DATABASE_URL="postgresql://..."
ANTHROPIC_API_KEY="sk-ant-..."

# Authentication (choose one)
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret"
# OR
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY="pk_test_..."
CLERK_SECRET_KEY="sk_test_..."

# Optional
AWS_ACCESS_KEY_ID="..."        # For S3 uploads
AWS_SECRET_ACCESS_KEY="..."
SMTP_HOST="smtp.gmail.com"     # For emails
```

See `.env.example` for complete list.

---

## 🚢 Deployment

### Vercel (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Production
vercel --prod
```

### Environment Setup

1. Add environment variables in Vercel dashboard
2. Connect your PostgreSQL database
3. Deploy!

### Alternative Platforms

- **Railway** - Database + hosting
- **Render** - Free tier available
- **DigitalOcean** - Full control

---

## 🧪 Testing

### Unit Tests

```bash
npm run test
```

### E2E Tests

```bash
npm run test:e2e
```

### Type Checking

```bash
npm run type-check
```

---

## 📚 Documentation

### For Developers

- [API Documentation](./docs/API.md)
- [Component Guide](./docs/COMPONENTS.md)
- [Database Schema](./docs/DATABASE.md)

### For Users

- [User Guide](./docs/USER_GUIDE.md)
- [Tutorial Videos](./docs/VIDEOS.md)
- [FAQ](./docs/FAQ.md)

---

## 🤝 Contributing

We welcome contributions! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing`)
5. Open a Pull Request

### Commit Convention

- `feat:` - New feature
- `fix:` - Bug fix
- `docs:` - Documentation
- `style:` - Formatting
- `refactor:` - Code refactoring
- `test:` - Tests
- `chore:` - Maintenance

---

## 📄 License

This project is licensed under the MIT License - see [LICENSE](LICENSE) file.

---

## 🙏 Acknowledgments

- Built with ❤️ by Lumen Systems
- Powered by [Anthropic's Claude AI](https://www.anthropic.com/)
- Built with The Giggle Frequency™

---

## 📧 Support

- **Documentation**: [docs.lumenbooks.com](https://docs.lumenbooks.com)
- **Email**: support@lumenbooks.com
- **GitHub Issues**: [github.com/hwinnwin/lumen-books/issues](https://github.com/hwinnwin/lumen-books/issues)

---

## 🗺 Roadmap

### Phase 1 - MVP (Current)
- [x] Landing page
- [x] Database schema
- [x] AI integration
- [ ] Authentication
- [ ] Basic editor
- [ ] PDF export

### Phase 2 - Core Features
- [ ] Templates library
- [ ] Collaboration tools
- [ ] Version control
- [ ] Multiple export formats

### Phase 3 - Advanced
- [ ] Course creation
- [ ] Real-time collaboration
- [ ] Analytics dashboard
- [ ] Mobile app

[See detailed roadmap →](./docs/ROADMAP.md)

---

**Ready to build the future of book creation! 🚀📚✨**

*Made with consciousness and joy by the Lumen Systems team*
