// ============================================
// USER TYPES
// ============================================

export interface User {
  id: string
  email: string
  name?: string
  avatarUrl?: string
  createdAt: Date
  updatedAt: Date
}

// ============================================
// PROJECT TYPES
// ============================================

export type ProjectType = 'BOOK' | 'COURSE' | 'OTHER'

export interface Project {
  id: string
  userId: string
  title: string
  description?: string
  type: ProjectType
  templateId?: string
  settings?: ProjectSettings
  coverImage?: string
  wordCount: number
  published: boolean
  createdAt: Date
  updatedAt: Date
}

export interface ProjectSettings {
  fontSize?: number
  fontFamily?: string
  lineHeight?: number
  margins?: {
    top: number
    right: number
    bottom: number
    left: number
  }
  pageSize?: string
  theme?: string
  customCSS?: string
}

// ============================================
// CONTENT TYPES
// ============================================

export type ContentBlockType =
  | 'CHAPTER'
  | 'SECTION'
  | 'LESSON'
  | 'QUIZ'
  | 'EXERCISE'
  | 'CONTENT'
  | 'FRONT_MATTER'
  | 'BACK_MATTER'

export interface ContentBlock {
  id: string
  projectId: string
  parentId?: string
  type: ContentBlockType
  title: string
  content: any // TipTap JSON
  order: number
  wordCount: number
  createdAt: Date
  updatedAt: Date
}

// ============================================
// TEMPLATE TYPES
// ============================================

export type TemplateCategory =
  | 'FICTION'
  | 'NONFICTION'
  | 'EDUCATIONAL'
  | 'BUSINESS'
  | 'TECHNICAL'
  | 'CREATIVE'
  | 'OTHER'

export interface Template {
  id: string
  name: string
  description?: string
  type: ProjectType
  category: TemplateCategory
  settings: TemplateSettings
  preview?: string
  isPublic: boolean
  userId?: string
  featured: boolean
  usageCount: number
  createdAt: Date
}

export interface TemplateSettings {
  structure?: {
    frontMatter?: string[]
    mainContent?: string[]
    backMatter?: string[]
  }
  formatting?: ProjectSettings
  placeholders?: Record<string, string>
}

// ============================================
// ASSET TYPES
// ============================================

export interface Asset {
  id: string
  projectId: string
  fileName: string
  fileType: string
  fileSize: number
  storagePath: string
  url?: string
  metadata?: AssetMetadata
  createdAt: Date
}

export interface AssetMetadata {
  width?: number
  height?: number
  altText?: string
  copyright?: string
  description?: string
}

// ============================================
// COLLABORATION TYPES
// ============================================

export type CollaboratorRole = 'OWNER' | 'EDITOR' | 'REVIEWER' | 'VIEWER'

export interface ProjectCollaborator {
  id: string
  projectId: string
  userId: string
  role: CollaboratorRole
  invitedAt: Date
  acceptedAt?: Date
}

export interface Comment {
  id: string
  projectId: string
  contentBlockId: string
  userId: string
  text: string
  position?: CommentPosition
  resolved: boolean
  parentId?: string
  createdAt: Date
  updatedAt: Date
}

export interface CommentPosition {
  from: number
  to: number
}

// ============================================
// VERSION CONTROL TYPES
// ============================================

export interface Version {
  id: string
  projectId: string
  userId: string
  snapshot: ProjectSnapshot
  message?: string
  tag?: string
  createdAt: Date
}

export interface ProjectSnapshot {
  project: Project
  content: ContentBlock[]
  timestamp: Date
}

// ============================================
// EXPORT TYPES
// ============================================

export type ExportFormat =
  | 'PDF'
  | 'EPUB'
  | 'MOBI'
  | 'DOCX'
  | 'HTML'
  | 'LATEX'
  | 'MARKDOWN'

export type ExportStatus = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED'

export interface Export {
  id: string
  projectId: string
  userId: string
  format: ExportFormat
  filePath?: string
  fileUrl?: string
  settings?: ExportSettings
  status: ExportStatus
  error?: string
  createdAt: Date
}

export interface ExportSettings {
  includeTableOfContents?: boolean
  includeCover?: boolean
  includePageNumbers?: boolean
  paperSize?: string
  margins?: {
    top: number
    right: number
    bottom: number
    left: number
  }
  fontSize?: number
  fontFamily?: string
  lineHeight?: number
}

// ============================================
// AI USAGE TYPES
// ============================================

export interface AIUsage {
  id: string
  userId: string
  projectId?: string
  feature: string
  tokensUsed: number
  cost?: number
  successful: boolean
  createdAt: Date
}

// ============================================
// API RESPONSE TYPES
// ============================================

export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  page: number
  perPage: number
  total: number
  totalPages: number
}

// ============================================
// EDITOR TYPES
// ============================================

export interface EditorState {
  content: string
  wordCount: number
  characterCount: number
  readingTime: number
  lastSaved?: Date
}

// ============================================
// FORM TYPES
// ============================================

export interface CreateProjectForm {
  title: string
  description?: string
  type: ProjectType
  templateId?: string
}

export interface UpdateProjectForm {
  title?: string
  description?: string
  settings?: Partial<ProjectSettings>
  coverImage?: string
}

export interface CreateContentBlockForm {
  projectId: string
  parentId?: string
  type: ContentBlockType
  title: string
  content?: any
  order: number
}

export interface UpdateContentBlockForm {
  title?: string
  content?: any
  order?: number
}

// ============================================
// ANALYTICS TYPES
// ============================================

export interface WritingStats {
  totalWords: number
  totalCharacters: number
  averageWordsPerDay: number
  writingStreak: number
  projectsCompleted: number
  chaptersCompleted: number
}

export interface ProjectAnalytics {
  wordCount: number
  characterCount: number
  chapterCount: number
  readingTime: number
  lastUpdated: Date
  completionPercentage: number
}
