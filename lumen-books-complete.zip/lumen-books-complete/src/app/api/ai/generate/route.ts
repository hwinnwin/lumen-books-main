import { NextResponse } from 'next/server'
import { generateContent, generateContentStream, prompts } from '@/lib/ai/claude'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { prompt, context, stream = false, promptType } = body

    // Validate input
    if (!prompt && !promptType) {
      return NextResponse.json(
        { success: false, error: 'Prompt or promptType is required' },
        { status: 400 }
      )
    }

    // Build the actual prompt
    let actualPrompt = prompt

    // Use pre-built prompts if specified
    if (promptType && prompts[promptType as keyof typeof prompts]) {
      const promptBuilder = prompts[promptType as keyof typeof prompts] as any
      actualPrompt = typeof promptBuilder === 'function' 
        ? promptBuilder(context || '') 
        : promptBuilder
    }

    // Handle streaming response
    if (stream) {
      const encoder = new TextEncoder()
      const customReadable = new ReadableStream({
        async start(controller) {
          try {
            const streamIterator = await generateContentStream(actualPrompt, {
              context,
              maxTokens: 2000,
              temperature: 0.7
            })

            for await (const chunk of streamIterator) {
              controller.enqueue(encoder.encode(`data: ${JSON.stringify({ text: chunk })}\n\n`))
            }

            controller.enqueue(encoder.encode('data: [DONE]\n\n'))
            controller.close()
          } catch (error) {
            controller.error(error)
          }
        }
      })

      return new Response(customReadable, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
        },
      })
    }

    // Handle regular response
    const text = await generateContent(actualPrompt, {
      context,
      maxTokens: 2000,
      temperature: 0.7
    })

    // Track AI usage (optional)
    // await trackAIUsage(userId, projectId, tokensUsed)

    return NextResponse.json({
      success: true,
      text,
      promptType,
    })

  } catch (error: any) {
    console.error('AI generation error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error.message || 'Failed to generate content' 
      },
      { status: 500 }
    )
  }
}

// ============================================
// GET - Return available prompts
// ============================================

export async function GET() {
  const availablePrompts = Object.keys(prompts).map(key => ({
    key,
    name: key.replace(/([A-Z])/g, ' $1').trim(),
  }))

  return NextResponse.json({
    success: true,
    prompts: availablePrompts
  })
}
