import Link from 'next/link'
import {
  BookOpen,
  FileText,
  Download,
  TrendingUp,
  Clock,
  Users,
  Plus,
  ArrowRight
} from 'lucide-react'

export default async function DashboardPage() {
  // TODO: Fetch real data from database
  const stats = {
    totalProjects: 12,
    activeProjects: 5,
    totalWords: 45678,
    exportsThisMonth: 8
  }

  const recentProjects = [
    {
      id: '1',
      title: 'The Future of AI',
      type: 'BOOK',
      updatedAt: new Date('2025-01-25'),
      wordCount: 12450,
      progress: 65
    },
    {
      id: '2',
      title: 'React Best Practices',
      type: 'COURSE',
      updatedAt: new Date('2025-01-24'),
      wordCount: 8900,
      progress: 40
    },
    {
      id: '3',
      title: 'My Memoir',
      type: 'BOOK',
      updatedAt: new Date('2025-01-20'),
      wordCount: 23100,
      progress: 85
    }
  ]

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Welcome back, John! 👋
        </h1>
        <p className="text-gray-600">
          Here's what's happening with your projects today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Projects"
          value={stats.totalProjects}
          icon={<FileText className="h-6 w-6" />}
          color="blue"
          trend="+2 this month"
        />
        <StatCard
          title="Active Projects"
          value={stats.activeProjects}
          icon={<BookOpen className="h-6 w-6" />}
          color="purple"
        />
        <StatCard
          title="Total Words"
          value={stats.totalWords.toLocaleString()}
          icon={<TrendingUp className="h-6 w-6" />}
          color="green"
          trend="+3,450 this week"
        />
        <StatCard
          title="Exports"
          value={stats.exportsThisMonth}
          icon={<Download className="h-6 w-6" />}
          color="orange"
          trend="This month"
        />
      </div>

      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ActionCard
            title="New Book"
            description="Start writing your next masterpiece"
            href="/dashboard/projects/new?type=book"
            icon={<BookOpen className="h-8 w-8" />}
            color="blue"
          />
          <ActionCard
            title="New Course"
            description="Create educational content"
            href="/dashboard/projects/new?type=course"
            icon={<FileText className="h-8 w-8" />}
            color="purple"
          />
          <ActionCard
            title="Browse Templates"
            description="Start from a professional template"
            href="/dashboard/templates"
            icon={<Users className="h-8 w-8" />}
            color="green"
          />
        </div>
      </div>

      {/* Recent Projects */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Recent Projects</h2>
          <Link
            href="/dashboard/projects"
            className="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium"
          >
            View all
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        
        <div className="space-y-4">
          {recentProjects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </div>
    </div>
  )
}

// ============================================
// STAT CARD
// ============================================

interface StatCardProps {
  title: string
  value: string | number
  icon: React.ReactNode
  color: 'blue' | 'purple' | 'green' | 'orange'
  trend?: string
}

function StatCard({ title, value, icon, color, trend }: StatCardProps) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600',
    purple: 'bg-purple-50 text-purple-600',
    green: 'bg-green-50 text-green-600',
    orange: 'bg-orange-50 text-orange-600'
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          {icon}
        </div>
      </div>
      <h3 className="text-2xl font-bold text-gray-900 mb-1">{value}</h3>
      <p className="text-sm text-gray-600">{title}</p>
      {trend && (
        <p className="text-xs text-gray-500 mt-2">{trend}</p>
      )}
    </div>
  )
}

// ============================================
// ACTION CARD
// ============================================

interface ActionCardProps {
  title: string
  description: string
  href: string
  icon: React.ReactNode
  color: 'blue' | 'purple' | 'green'
}

function ActionCard({ title, description, href, icon, color }: ActionCardProps) {
  const colorClasses = {
    blue: 'from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700',
    purple: 'from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700',
    green: 'from-green-500 to-green-600 hover:from-green-600 hover:to-green-700'
  }

  return (
    <Link
      href={href}
      className={`
        block p-6 rounded-lg bg-gradient-to-br ${colorClasses[color]}
        text-white transition-all transform hover:scale-105
      `}
    >
      <div className="mb-4">{icon}</div>
      <h3 className="text-lg font-semibold mb-1">{title}</h3>
      <p className="text-sm text-white/90">{description}</p>
    </Link>
  )
}

// ============================================
// PROJECT CARD
// ============================================

interface ProjectCardProps {
  project: {
    id: string
    title: string
    type: string
    updatedAt: Date
    wordCount: number
    progress: number
  }
}

function ProjectCard({ project }: ProjectCardProps) {
  const timeAgo = formatTimeAgo(project.updatedAt)

  return (
    <Link
      href={`/dashboard/editor/${project.id}`}
      className="block bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-1">
            {project.title}
          </h3>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              Updated {timeAgo}
            </span>
            <span>{project.wordCount.toLocaleString()} words</span>
            <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs font-medium">
              {project.type}
            </span>
          </div>
        </div>
      </div>
      
      {/* Progress Bar */}
      <div>
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-gray-600">Progress</span>
          <span className="font-medium text-gray-900">{project.progress}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-blue-600 h-2 rounded-full transition-all"
            style={{ width: `${project.progress}%` }}
          />
        </div>
      </div>
    </Link>
  )
}

// ============================================
// HELPERS
// ============================================

function formatTimeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)
  
  if (seconds < 60) return 'just now'
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`
  return date.toLocaleDateString()
}
