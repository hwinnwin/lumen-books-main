'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  BookOpen,
  FileText,
  Grid,
  List,
  Search,
  Filter,
  Plus,
  Clock,
  MoreVertical,
  Trash2,
  Copy,
  Download
} from 'lucide-react'

export default function ProjectsPage() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [filter, setFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')

  // TODO: Fetch from database
  const projects = [
    {
      id: '1',
      title: 'The Future of AI',
      description: 'A comprehensive guide to artificial intelligence and its impact on society',
      type: 'BOOK',
      updatedAt: new Date('2025-01-25'),
      wordCount: 12450,
      progress: 65,
      coverImage: null
    },
    {
      id: '2',
      title: 'React Best Practices 2025',
      description: 'Learn modern React patterns and techniques',
      type: 'COURSE',
      updatedAt: new Date('2025-01-24'),
      wordCount: 8900,
      progress: 40,
      coverImage: null
    },
    {
      id: '3',
      title: 'My Memoir: A Journey',
      description: 'Personal stories from my entrepreneurial journey',
      type: 'BOOK',
      updatedAt: new Date('2025-01-20'),
      wordCount: 23100,
      progress: 85,
      coverImage: null
    },
    {
      id: '4',
      title: 'JavaScript Fundamentals',
      description: 'Complete JavaScript course for beginners',
      type: 'COURSE',
      updatedAt: new Date('2025-01-18'),
      wordCount: 15600,
      progress: 55,
      coverImage: null
    },
    {
      id: '5',
      title: 'Marketing Secrets',
      description: 'Proven strategies for digital marketing success',
      type: 'BOOK',
      updatedAt: new Date('2025-01-15'),
      wordCount: 18200,
      progress: 72,
      coverImage: null
    },
    {
      id: '6',
      title: 'Python for Data Science',
      description: 'Learn Python programming for data analysis',
      type: 'COURSE',
      updatedAt: new Date('2025-01-12'),
      wordCount: 11400,
      progress: 30,
      coverImage: null
    }
  ]

  const filteredProjects = projects.filter(project => {
    const matchesFilter = filter === 'all' || project.type === filter
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesFilter && matchesSearch
  })

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Projects</h1>
          <p className="text-gray-600">
            {filteredProjects.length} project{filteredProjects.length !== 1 ? 's' : ''}
          </p>
        </div>
        <Link
          href="/dashboard/projects/new"
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-5 w-5" />
          New Project
        </Link>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        {/* Search */}
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search projects..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Filter */}
        <div className="flex items-center gap-4">
          <div className="flex gap-2">
            <FilterButton
              active={filter === 'all'}
              onClick={() => setFilter('all')}
              label="All"
            />
            <FilterButton
              active={filter === 'BOOK'}
              onClick={() => setFilter('BOOK')}
              label="Books"
            />
            <FilterButton
              active={filter === 'COURSE'}
              onClick={() => setFilter('COURSE')}
              label="Courses"
            />
          </div>

          {/* View Toggle */}
          <div className="flex border border-gray-300 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 ${viewMode === 'grid' ? 'bg-gray-100' : 'hover:bg-gray-50'}`}
            >
              <Grid className="h-5 w-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 ${viewMode === 'list' ? 'bg-gray-100' : 'hover:bg-gray-50'}`}
            >
              <List className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Projects Grid/List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <ProjectGridCard key={project.id} project={project} />
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredProjects.map((project) => (
            <ProjectListCard key={project.id} project={project} />
          ))}
        </div>
      )}

      {/* Empty State */}
      {filteredProjects.length === 0 && (
        <div className="text-center py-20">
          <BookOpen className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            No projects found
          </h3>
          <p className="text-gray-600 mb-6">
            {searchQuery ? 'Try a different search term' : 'Get started by creating your first project'}
          </p>
          <Link
            href="/dashboard/projects/new"
            className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plus className="h-5 w-5" />
            New Project
          </Link>
        </div>
      )}
    </div>
  )
}

// ============================================
// FILTER BUTTON
// ============================================

interface FilterButtonProps {
  active: boolean
  onClick: () => void
  label: string
}

function FilterButton({ active, onClick, label }: FilterButtonProps) {
  return (
    <button
      onClick={onClick}
      className={`
        px-4 py-2 rounded-lg font-medium transition-colors
        ${active
          ? 'bg-blue-600 text-white'
          : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
        }
      `}
    >
      {label}
    </button>
  )
}

// ============================================
// PROJECT GRID CARD
// ============================================

interface ProjectGridCardProps {
  project: any
}

function ProjectGridCard({ project }: ProjectGridCardProps) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow group">
      {/* Cover Image */}
      <div className="h-48 bg-gradient-to-br from-blue-500 to-purple-600 relative">
        {project.type === 'BOOK' ? (
          <BookOpen className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-20 w-20 text-white/30" />
        ) : (
          <FileText className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-20 w-20 text-white/30" />
        )}
        
        {/* Type Badge */}
        <div className="absolute top-4 right-4">
          <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-gray-900 rounded-full text-xs font-medium">
            {project.type}
          </span>
        </div>

        {/* Actions Menu */}
        <div className="absolute top-4 left-4">
          <ProjectMenu projectId={project.id} />
        </div>
      </div>

      {/* Content */}
      <Link href={`/dashboard/editor/${project.id}`} className="block p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-blue-600">
          {project.title}
        </h3>
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">
          {project.description}
        </p>

        <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
          <span className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            {formatTimeAgo(project.updatedAt)}
          </span>
          <span>{project.wordCount.toLocaleString()} words</span>
        </div>

        {/* Progress */}
        <div>
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-gray-600">Progress</span>
            <span className="font-medium">{project.progress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full"
              style={{ width: `${project.progress}%` }}
            />
          </div>
        </div>
      </Link>
    </div>
  )
}

// ============================================
// PROJECT LIST CARD
// ============================================

function ProjectListCard({ project }: ProjectGridCardProps) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow group">
      <div className="flex items-center gap-6">
        {/* Icon */}
        <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
          {project.type === 'BOOK' ? (
            <BookOpen className="h-8 w-8 text-white" />
          ) : (
            <FileText className="h-8 w-8 text-white" />
          )}
        </div>

        {/* Content */}
        <Link href={`/dashboard/editor/${project.id}`} className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 mb-1 group-hover:text-blue-600">
                {project.title}
              </h3>
              <p className="text-sm text-gray-600 line-clamp-1">
                {project.description}
              </p>
            </div>
            <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium ml-4">
              {project.type}
            </span>
          </div>

          <div className="flex items-center gap-6 text-sm text-gray-600">
            <span className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              Updated {formatTimeAgo(project.updatedAt)}
            </span>
            <span>{project.wordCount.toLocaleString()} words</span>
            <div className="flex items-center gap-2 flex-1">
              <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-xs">
                <div
                  className="bg-blue-600 h-2 rounded-full"
                  style={{ width: `${project.progress}%` }}
                />
              </div>
              <span className="font-medium min-w-[3rem] text-right">{project.progress}%</span>
            </div>
          </div>
        </Link>

        {/* Actions */}
        <ProjectMenu projectId={project.id} />
      </div>
    </div>
  )
}

// ============================================
// PROJECT MENU
// ============================================

function ProjectMenu({ projectId }: { projectId: string }) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 hover:bg-white/20 rounded-lg transition-colors"
      >
        <MoreVertical className="h-5 w-5" />
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-10"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-20">
            <button className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2">
              <Copy className="h-4 w-4" />
              Duplicate
            </button>
            <button className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2">
              <Download className="h-4 w-4" />
              Export
            </button>
            <hr className="my-1" />
            <button className="w-full px-4 py-2 text-left text-sm hover:bg-red-50 text-red-600 flex items-center gap-2">
              <Trash2 className="h-4 w-4" />
              Delete
            </button>
          </div>
        </>
      )}
    </div>
  )
}

// ============================================
// HELPERS
// ============================================

function formatTimeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)
  
  if (seconds < 60) return 'just now'
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`
  return date.toLocaleDateString()
}
