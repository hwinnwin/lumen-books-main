import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

export const claude = client

export interface AIAssistantOptions {
  context?: string
  maxTokens?: number
  temperature?: number
  systemPrompt?: string
}

export async function generateContent(
  prompt: string,
  options: AIAssistantOptions = {}
): Promise<string> {
  const {
    context = '',
    maxTokens = 2000,
    temperature = 0.7,
    systemPrompt = 'You are a helpful writing assistant for book and course creation. Help users create professional, engaging content.',
  } = options

  const message = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: maxTokens,
    temperature,
    system: systemPrompt,
    messages: [
      {
        role: 'user',
        content: context ? `${context}\n\n${prompt}` : prompt,
      },
    ],
  })

  const textContent = message.content.find((block) => block.type === 'text')
  return textContent?.type === 'text' ? textContent.text : ''
}

export async function generateContentStream(
  prompt: string,
  options: AIAssistantOptions = {}
): Promise<AsyncIterable<string>> {
  const {
    context = '',
    maxTokens = 2000,
    temperature = 0.7,
    systemPrompt = 'You are a helpful writing assistant for book and course creation.',
  } = options

  const stream = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: maxTokens,
    temperature,
    system: systemPrompt,
    stream: true,
    messages: [
      {
        role: 'user',
        content: context ? `${context}\n\n${prompt}` : prompt,
      },
    ],
  })

  async function* generateText() {
    for await (const event of stream) {
      if (
        event.type === 'content_block_delta' &&
        event.delta.type === 'text_delta'
      ) {
        yield event.delta.text
      }
    }
  }

  return generateText()
}

// ============================================
// SPECIALIZED PROMPTS FOR BOOK WRITING
// ============================================

export const prompts = {
  // Content Generation
  expandParagraph: (text: string) =>
    `Expand the following paragraph with more detail, depth, and richness while maintaining the same tone and style:\n\n${text}`,

  generateChapter: (outline: string, chapterTitle: string, style: string = 'engaging and accessible') =>
    `Based on this outline:\n\n${outline}\n\nWrite a complete, ${style} chapter titled: "${chapterTitle}"\n\nInclude vivid descriptions, smooth transitions, and compelling content.`,

  generateOutline: (topic: string, chapters: number, bookType: string = 'book') =>
    `Generate a detailed outline for a ${bookType} about "${topic}" with ${chapters} chapters.\n\nFor each chapter provide:\n- A compelling chapter title\n- 3-5 key subsections\n- Brief description of what each section covers`,

  continueStory: (existingContent: string) =>
    `Continue the following story naturally, maintaining the same tone, style, and narrative voice:\n\n${existingContent}`,

  // Improvement & Editing
  improveGrammar: (text: string) =>
    `Improve the grammar, clarity, and flow of the following text while preserving the original meaning and voice:\n\n${text}`,

  changeTone: (text: string, tone: string) =>
    `Rewrite the following text in a ${tone} tone:\n\n${text}`,

  makeMoreConcise: (text: string) =>
    `Make the following text more concise while preserving all key information:\n\n${text}`,

  makeMoreDetailed: (text: string) =>
    `Add more detail, examples, and depth to the following text:\n\n${text}`,

  // Creative Writing
  generateDialogue: (context: string, characters: string[], mood: string = 'natural') =>
    `Generate ${mood} dialogue between ${characters.join(' and ')} in the following context:\n\n${context}\n\nMake it feel authentic and character-driven.`,

  generateDescription: (subject: string, style: string = 'vivid and sensory-rich') =>
    `Write a ${style} description of: ${subject}`,

  developCharacter: (characterName: string, traits: string) =>
    `Develop a detailed character profile for "${characterName}" with these traits: ${traits}\n\nInclude:\n- Background\n- Motivations\n- Conflicts\n- Growth arc\n- Unique voice`,

  // Non-Fiction
  explainConcept: (concept: string, audience: string = 'general readers') =>
    `Explain the concept of "${concept}" for ${audience}. Make it clear, engaging, and accessible.`,

  generateExample: (concept: string) =>
    `Provide a concrete, real-world example that illustrates: ${concept}`,

  createExercise: (topic: string, difficulty: string = 'moderate') =>
    `Create a ${difficulty} difficulty exercise or practice problem for learning about: ${topic}\n\nInclude:\n- Clear instructions\n- Expected outcome\n- Learning objectives`,

  // Analysis & Review
  analyzePacing: (text: string) =>
    `Analyze the pacing of the following text and suggest improvements:\n\n${text}`,

  checkConsistency: (text: string, characters: string[]) =>
    `Check the following text for consistency issues with these characters: ${characters.join(', ')}\n\nText:\n${text}`,

  generateSummary: (text: string, length: 'short' | 'medium' | 'long' = 'medium') =>
    `Provide a ${length} summary of the following text:\n\n${text}`,

  // Course Creation
  createLessonPlan: (topic: string, duration: string, level: string) =>
    `Create a ${duration} lesson plan about "${topic}" for ${level} learners.\n\nInclude:\n- Learning objectives\n- Key concepts\n- Activities\n- Assessment methods`,

  generateQuiz: (topic: string, questions: number = 5) =>
    `Create ${questions} multiple-choice questions about "${topic}". Include the correct answer and explanation for each.`,

  createStudyGuide: (chapterContent: string) =>
    `Create a comprehensive study guide for the following chapter:\n\n${chapterContent}\n\nInclude:\n- Key concepts\n- Summary\n- Practice questions\n- Further reading suggestions`,

  // Translation & Localization
  translate: (text: string, targetLanguage: string) =>
    `Translate the following text to ${targetLanguage}, maintaining the tone and style:\n\n${text}`,

  // Marketing & Metadata
  generateBookDescription: (bookSummary: string, genre: string) =>
    `Write a compelling book description for this ${genre} book:\n\n${bookSummary}\n\nMake it engaging and marketable, highlighting what makes the book unique.`,

  generateChapterSummary: (chapterContent: string) =>
    `Write a brief, enticing summary of this chapter:\n\n${chapterContent}`,

  suggestKeywords: (bookDescription: string) =>
    `Suggest 10-15 SEO-friendly keywords for a book with this description:\n\n${bookDescription}`,

  // Brainstorming
  generateIdeas: (topic: string, count: number = 10) =>
    `Generate ${count} creative ideas related to: ${topic}`,

  suggestPlotTwist: (currentPlot: string) =>
    `Given this plot:\n\n${currentPlot}\n\nSuggest a compelling plot twist that would surprise readers while remaining believable.`,

  // Technical Writing
  createAPIDocumentation: (apiDescription: string) =>
    `Create clear, comprehensive API documentation for:\n\n${apiDescription}\n\nInclude parameters, return values, and examples.`,

  simplifyTechnicalContent: (technicalText: string) =>
    `Simplify the following technical content for a non-technical audience:\n\n${technicalText}`,
}

// ============================================
// CONTEXT BUILDERS
// ============================================

export function buildBookContext(book: {
  title: string
  type: string
  genre?: string
  targetAudience?: string
  style?: string
}): string {
  return `Book Title: ${book.title}
Type: ${book.type}
${book.genre ? `Genre: ${book.genre}` : ''}
${book.targetAudience ? `Target Audience: ${book.targetAudience}` : ''}
${book.style ? `Writing Style: ${book.style}` : ''}`
}

export function buildChapterContext(chapter: {
  number: number
  title: string
  summary?: string
  existingContent?: string
}): string {
  return `Chapter ${chapter.number}: ${chapter.title}
${chapter.summary ? `Summary: ${chapter.summary}` : ''}
${chapter.existingContent ? `\nExisting Content:\n${chapter.existingContent}` : ''}`
}
