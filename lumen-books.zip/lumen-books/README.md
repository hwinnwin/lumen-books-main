# 📚 Lumen Books

> AI-powered book and course creation platform built with Next.js, TipTap, and Claude AI

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.3-blue)](https://www.typescriptlang.org/)
[![Next.js](https://img.shields.io/badge/Next.js-14-black)](https://nextjs.org/)

## 🌟 Features

- **Rich Text Editor** - Powered by TipTap with advanced formatting
- **AI Writing Assistant** - Claude AI integration for content generation
- **Multi-Format Export** - PDF, EPUB, DOCX, and more
- **Real-time Collaboration** - Work together with your team
- **Template Library** - Professional book templates
- **Course Creation** - Build complete educational courses
- **Version Control** - Never lose your work
- **Print-Ready** - Professional-grade PDF output

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm 9+
- PostgreSQL database
- Anthropic API key (for AI features)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/hwinnwin/lumen-books.git
   cd lumen-books
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   ```
   
   Edit `.env.local` with your credentials:
   - Database connection string
   - Anthropic API key
   - Authentication provider credentials

4. **Set up the database**
   ```bash
   npm run db:push
   ```

5. **Run the development server**
   ```bash
   npm run dev
   ```

6. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## 🏗️ Project Structure

```
lumen-books/
├── src/
│   ├── app/                    # Next.js app router
│   │   ├── (auth)/            # Authentication pages
│   │   ├── (dashboard)/       # Main application
│   │   ├── api/               # API routes
│   │   └── layout.tsx
│   ├── components/
│   │   ├── editor/            # Text editor components
│   │   ├── ui/                # UI components (shadcn)
│   │   └── shared/            # Shared components
│   ├── lib/
│   │   ├── ai/                # AI integration
│   │   ├── export/            # Export engines (PDF, EPUB, etc.)
│   │   ├── db/                # Database client
│   │   └── utils/             # Utility functions
│   ├── hooks/                 # React hooks
│   ├── types/                 # TypeScript types
│   └── styles/                # Global styles
├── prisma/
│   ├── schema.prisma          # Database schema
│   └── migrations/            # Database migrations
├── public/                    # Static assets
└── docs/                      # Documentation
```

## 🛠️ Tech Stack

### Core
- **Next.js 14** - React framework with App Router
- **TypeScript** - Type safety
- **PostgreSQL** - Database
- **Prisma** - ORM

### Editor
- **TipTap** - Rich text editor
- **ProseMirror** - Editor foundation

### AI
- **Anthropic Claude** - AI writing assistant
- **@anthropic-ai/sdk** - Claude API client

### UI
- **Tailwind CSS** - Styling
- **shadcn/ui** - Component library
- **Radix UI** - Accessible primitives
- **Framer Motion** - Animations

### Export
- **pdfkit** - PDF generation
- **epub-gen** - EPUB creation
- **docx** - Word documents

### State Management
- **Zustand** / **Jotai** - State management
- **TanStack Query** - Server state

## 📖 Documentation

- [Feature List](./docs/FEATURES.md)
- [Implementation Plan](./docs/IMPLEMENTATION.md)
- [API Documentation](./docs/API.md)
- [Contributing Guide](./docs/CONTRIBUTING.md)

## 🎯 Roadmap

### Phase 1: MVP (Weeks 1-4)
- [x] Project setup
- [ ] Core editor
- [ ] Basic export (PDF)
- [ ] Authentication

### Phase 2: Export & Templates (Weeks 5-8)
- [ ] Multi-format export
- [ ] Template system
- [ ] Cover design

### Phase 3: AI Integration (Weeks 9-12)
- [ ] AI writing assistant
- [ ] Content generation
- [ ] Quality checks

### Phase 4: Collaboration (Weeks 13-16)
- [ ] Real-time editing
- [ ] Comments and reviews
- [ ] Version control

### Phase 5: Course Creation (Weeks 17-20)
- [ ] Course structure
- [ ] Interactive elements
- [ ] Student materials

### Phase 6: Launch (Weeks 21-24)
- [ ] Polish and optimization
- [ ] Beta testing
- [ ] Public launch

## 🧪 Development

### Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Run ESLint
npm run type-check   # Run TypeScript compiler
npm run format       # Format code with Prettier
npm run db:push      # Push schema changes to database
npm run db:studio    # Open Prisma Studio
npm run test         # Run tests
```

### Database Management

```bash
# Create a migration
npm run db:migrate

# Reset database
npx prisma migrate reset

# Seed database
npx prisma db seed
```

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](./docs/CONTRIBUTING.md) for details.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with ❤️ by [HwinNwin Enterprises](https://github.com/hwinnwin)
- Part of the Lumen Systems ecosystem
- Powered by Anthropic's Claude AI

## 📧 Contact

- **Website**: [Coming Soon]
- **Email**: [Your Email]
- **GitHub**: [@hwinnwin](https://github.com/hwinnwin)

## 🌈 The Giggle Frequency™

This project is built with consciousness and joy at its core. We believe in creating tools that empower people to share their knowledge and stories with the world.

---

**Happy writing! 📚✨**
