import Link from 'next/link'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <h1 className="text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            Lumen Books
          </h1>
          <p className="text-2xl text-gray-600 mb-8">
            AI-Powered Book & Course Creation Platform
          </p>
          <p className="text-lg text-gray-500 mb-12 max-w-2xl mx-auto">
            Create professional books and courses with the power of AI. From first draft
            to published masterpiece, Lumen Books guides you every step of the way.
          </p>
          <div className="flex gap-4 justify-center">
            <Link
              href="/dashboard"
              className="px-8 py-4 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Get Started
            </Link>
            <Link
              href="/docs"
              className="px-8 py-4 bg-white text-blue-600 border-2 border-blue-600 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Learn More
            </Link>
          </div>
        </div>

        <div className="mt-24 grid md:grid-cols-3 gap-8">
          <FeatureCard
            icon="✍️"
            title="AI Writing Assistant"
            description="Let Claude AI help you write, edit, and improve your content with intelligent suggestions."
          />
          <FeatureCard
            icon="📚"
            title="Professional Output"
            description="Export to PDF, EPUB, DOCX, and more with print-ready quality."
          />
          <FeatureCard
            icon="🎓"
            title="Course Creation"
            description="Build complete educational courses with lessons, quizzes, and interactive elements."
          />
          <FeatureCard
            icon="👥"
            title="Collaboration"
            description="Work together with your team in real-time with comments and version control."
          />
          <FeatureCard
            icon="🎨"
            title="Beautiful Templates"
            description="Start with professional templates for fiction, non-fiction, textbooks, and more."
          />
          <FeatureCard
            icon="📊"
            title="Analytics"
            description="Track your progress, writing habits, and reader engagement."
          />
        </div>
      </div>
    </div>
  )
}

interface FeatureCardProps {
  icon: string
  title: string
  description: string
}

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  )
}
