// Project Types
export type ProjectType = 'BOOK' | 'COURSE' | 'OTHER'

export interface Project {
  id: string
  userId: string
  title: string
  type: ProjectType
  templateId?: string
  settings?: Record<string, any>
  createdAt: Date
  updatedAt: Date
}

// Content Block Types
export type ContentBlockType =
  | 'CHAPTER'
  | 'SECTION'
  | 'LESSON'
  | 'QUIZ'
  | 'EXERCISE'
  | 'CONTENT'

export interface ContentBlock {
  id: string
  projectId: string
  parentId?: string
  type: ContentBlockType
  title: string
  content: any // JSON content from TipTap
  order: number
  createdAt: Date
  updatedAt: Date
}

// Template Types
export type TemplateCategory =
  | 'FICTION'
  | 'NONFICTION'
  | 'EDUCATIONAL'
  | 'BUSINESS'
  | 'TECHNICAL'
  | 'OTHER'

export interface Template {
  id: string
  name: string
  description?: string
  type: ProjectType
  category: TemplateCategory
  settings: Record<string, any>
  isPublic: boolean
  userId?: string
  createdAt: Date
}

// Export Types
export type ExportFormat = 'PDF' | 'EPUB' | 'MOBI' | 'DOCX' | 'HTML' | 'LATEX'
export type ExportStatus = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED'

export interface Export {
  id: string
  projectId: string
  userId: string
  format: ExportFormat
  filePath?: string
  settings?: Record<string, any>
  status: ExportStatus
  error?: string
  createdAt: Date
}

// Collaboration Types
export type CollaboratorRole = 'OWNER' | 'EDITOR' | 'REVIEWER' | 'VIEWER'

export interface ProjectCollaborator {
  id: string
  projectId: string
  userId: string
  role: CollaboratorRole
  createdAt: Date
}

// Comment Types
export interface Comment {
  id: string
  projectId: string
  contentBlockId: string
  userId: string
  text: string
  position?: Record<string, any>
  resolved: boolean
  createdAt: Date
}

// Version Types
export interface Version {
  id: string
  projectId: string
  userId: string
  snapshot: Record<string, any>
  message?: string
  createdAt: Date
}

// Asset Types
export interface Asset {
  id: string
  projectId: string
  fileName: string
  fileType: string
  fileSize: number
  storagePath: string
  metadata?: Record<string, any>
  createdAt: Date
}

// User Types
export interface User {
  id: string
  email: string
  name?: string
  avatarUrl?: string
  createdAt: Date
  updatedAt: Date
}

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

// Editor Types
export interface EditorState {
  content: string
  wordCount: number
  characterCount: number
  readingTime: number
}

// AI Assistant Types
export interface AIRequest {
  prompt: string
  context?: string
  maxTokens?: number
  temperature?: number
}

export interface AIResponse {
  text: string
  usage?: {
    inputTokens: number
    outputTokens: number
  }
}

// Export Settings Types
export interface PDFSettings {
  pageSize: string
  margins: {
    top: number
    right: number
    bottom: number
    left: number
  }
  fontSize: number
  fontFamily: string
  lineHeight: number
  includeTableOfContents: boolean
  includeCover: boolean
}

export interface EPUBSettings {
  author: string
  publisher?: string
  isbn?: string
  language: string
  coverImage?: string
}
