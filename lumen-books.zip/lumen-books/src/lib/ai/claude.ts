import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

export const claude = client

export interface AIAssistantOptions {
  context?: string
  maxTokens?: number
  temperature?: number
  systemPrompt?: string
}

export async function generateContent(
  prompt: string,
  options: AIAssistantOptions = {}
): Promise<string> {
  const {
    context = '',
    maxTokens = 2000,
    temperature = 0.7,
    systemPrompt = 'You are a helpful writing assistant for book and course creation.',
  } = options

  const message = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: maxTokens,
    temperature,
    system: systemPrompt,
    messages: [
      {
        role: 'user',
        content: context ? `${context}\n\n${prompt}` : prompt,
      },
    ],
  })

  const textContent = message.content.find((block) => block.type === 'text')
  return textContent?.type === 'text' ? textContent.text : ''
}

export async function generateContentStream(
  prompt: string,
  options: AIAssistantOptions = {}
): Promise<AsyncIterable<string>> {
  const {
    context = '',
    maxTokens = 2000,
    temperature = 0.7,
    systemPrompt = 'You are a helpful writing assistant for book and course creation.',
  } = options

  const stream = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: maxTokens,
    temperature,
    system: systemPrompt,
    stream: true,
    messages: [
      {
        role: 'user',
        content: context ? `${context}\n\n${prompt}` : prompt,
      },
    ],
  })

  async function* generateText() {
    for await (const event of stream) {
      if (
        event.type === 'content_block_delta' &&
        event.delta.type === 'text_delta'
      ) {
        yield event.delta.text
      }
    }
  }

  return generateText()
}

// Specialized prompts for book writing
export const prompts = {
  expandParagraph: (text: string) =>
    `Expand the following paragraph with more detail and depth while maintaining the same tone and style:\n\n${text}`,

  improveGrammar: (text: string) =>
    `Improve the grammar and clarity of the following text while preserving the original meaning:\n\n${text}`,

  changeTone: (text: string, tone: string) =>
    `Rewrite the following text in a ${tone} tone:\n\n${text}`,

  generateOutline: (topic: string, chapters: number) =>
    `Generate a detailed outline for a book about "${topic}" with ${chapters} chapters. Include chapter titles and 3-5 subsections for each chapter.`,

  generateChapter: (outline: string, chapterTitle: string) =>
    `Based on this book outline:\n\n${outline}\n\nWrite a complete chapter for: "${chapterTitle}"`,

  generateSummary: (text: string) =>
    `Provide a concise summary of the following text:\n\n${text}`,

  checkConsistency: (text: string, characters: string[]) =>
    `Check the following text for character consistency. Characters: ${characters.join(', ')}\n\nText:\n${text}`,

  generateDialogue: (context: string, characters: string[]) =>
    `Generate realistic dialogue between ${characters.join(' and ')} in the following context:\n\n${context}`,

  generateDescription: (subject: string) =>
    `Write a vivid, sensory-rich description of: ${subject}`,
}
