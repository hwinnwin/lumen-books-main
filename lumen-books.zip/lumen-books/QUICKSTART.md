# 🚀 Lumen Books - Quick Start Guide

## Getting Started in 5 Minutes

### 1. Prerequisites Check

Make sure you have:
- ✅ Node.js 18+ installed (`node --version`)
- ✅ npm 9+ installed (`npm --version`)
- ✅ PostgreSQL database running
- ✅ Anthropic API key (get one at https://console.anthropic.com/)

### 2. Clone & Install

```bash
# Clone the repository
git clone https://github.com/hwinnwin/lumen-books.git
cd lumen-books

# Install dependencies
npm install
```

### 3. Environment Setup

```bash
# Copy the environment template
cp .env.example .env.local

# Edit .env.local with your credentials
# Required:
# - DATABASE_URL (your PostgreSQL connection string)
# - ANTHROPIC_API_KEY (your Claude API key)
```

Example `.env.local`:
```env
DATABASE_URL="postgresql://postgres:password@localhost:5432/lumen_books"
ANTHROPIC_API_KEY="sk-ant-api03-..."
NEXT_PUBLIC_APP_URL="http://localhost:3000"
```

### 4. Database Setup

```bash
# Push the schema to your database
npm run db:push

# Open Prisma Studio to verify (optional)
npm run db:studio
```

### 5. Run the App

```bash
# Start the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser. You should see the Lumen Books homepage! 🎉

---

## What's Next?

### Immediate Next Steps

1. **Set up Authentication**
   - Choose between Clerk or NextAuth.js
   - Add credentials to `.env.local`
   - Uncomment auth provider in the code

2. **Create Your First Project**
   - Navigate to `/dashboard`
   - Click "New Project"
   - Choose a template
   - Start writing!

3. **Test AI Features**
   - Open the editor
   - Select some text
   - Click "AI Assist" to see Claude in action

### Development Workflow

```bash
# Available commands:
npm run dev          # Start dev server (localhost:3000)
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Check code quality
npm run type-check   # Check TypeScript types
npm run format       # Format code with Prettier
npm run db:studio    # Open database GUI
npm run db:migrate   # Create new migration
```

---

## Project Structure Overview

```
lumen-books/
├── src/
│   ├── app/                  # Next.js pages & routes
│   │   ├── (auth)/          # Login, signup, etc.
│   │   ├── (dashboard)/     # Main app (after login)
│   │   └── api/             # API endpoints
│   ├── components/
│   │   ├── editor/          # Text editor components
│   │   ├── ui/              # Reusable UI components
│   │   └── shared/          # Shared across app
│   ├── lib/
│   │   ├── ai/              # Claude AI integration
│   │   ├── export/          # PDF, EPUB generators
│   │   ├── db/              # Database client
│   │   └── utils/           # Helper functions
│   └── types/               # TypeScript definitions
└── prisma/
    └── schema.prisma        # Database schema
```

---

## Common Tasks

### Creating a New Page

```bash
# Create a new page in src/app/
# For example, src/app/pricing/page.tsx

export default function PricingPage() {
  return <div>Pricing page</div>
}
```

### Adding a New Component

```bash
# Create in src/components/
# For example, src/components/shared/Logo.tsx

export function Logo() {
  return <div>Lumen Books</div>
}
```

### Adding a Database Model

1. Edit `prisma/schema.prisma`
2. Add your model:
   ```prisma
   model MyNewModel {
     id        String   @id @default(uuid())
     name      String
     createdAt DateTime @default(now())
   }
   ```
3. Push to database: `npm run db:push`
4. Generate types: `npm run db:generate`

### Creating an API Route

```typescript
// src/app/api/my-route/route.ts
import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({ message: 'Hello!' })
}
```

---

## Troubleshooting

### Port 3000 is already in use

```bash
# Kill the process using port 3000
npx kill-port 3000

# Or use a different port
npm run dev -- -p 3001
```

### Database connection failed

1. Make sure PostgreSQL is running
2. Check your DATABASE_URL in `.env.local`
3. Try connecting with `psql` or a GUI tool first
4. Create the database if it doesn't exist:
   ```sql
   CREATE DATABASE lumen_books;
   ```

### Prisma errors

```bash
# Reset everything and start fresh
npx prisma migrate reset

# Or just regenerate the client
npm run db:generate
```

### Build errors

```bash
# Clear Next.js cache
rm -rf .next

# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Check TypeScript errors
npm run type-check
```

---

## Development Tips

### Hot Module Replacement (HMR)

Changes to files will auto-reload in the browser. No need to restart the server!

### Database Viewer

```bash
npm run db:studio
```

Opens Prisma Studio at http://localhost:5555 - a GUI for your database.

### Environment Variables

- `.env.local` - Your local secrets (NOT committed to git)
- `.env.example` - Template for others (committed to git)

Remember to restart the dev server after changing environment variables!

### Code Quality

```bash
# Before committing, run:
npm run lint         # Check for code issues
npm run type-check   # Check TypeScript
npm run format       # Format your code
```

---

## Resources

- **Next.js Docs**: https://nextjs.org/docs
- **TipTap Docs**: https://tiptap.dev/docs
- **Prisma Docs**: https://www.prisma.io/docs
- **Anthropic Docs**: https://docs.anthropic.com
- **Tailwind CSS**: https://tailwindcss.com/docs

---

## Need Help?

1. Check the main [README.md](./README.md)
2. Look at [IMPLEMENTATION.md](./docs/IMPLEMENTATION.md) for architecture details
3. Browse [FEATURES.md](./docs/FEATURES.md) for feature specifications
4. Open an issue on GitHub

---

**Happy coding! Let's build something amazing! 🚀**
